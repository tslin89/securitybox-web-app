import { Outlet } from 'react-router-dom';
// import your MUI AppBar/Drawer here
export default function AppShell() {
  return (
    <>
      {/* AppBar / Drawer / etc. */}
      <main>
        <Outlet />
      </main>
    </>
  );
}
