import React, { useState, useEffect, useRef } from 'react';
import { UserLogin, ensurePushSubscribed } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { useSignalR } from '../contexts/SignalRContext';
import { useAuth } from '../contexts/AuthContext';

const Login = () => {
  const [email, setUseremail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { login, isAuthenticated } = useAuth();

  const { startConnection } = useSignalR();
  const emailRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  // Redirect to translist if already authenticated
  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      navigate('/translist', { replace: true });
    }
  }, [isAuthenticated, isLoading, navigate]);

  useEffect(() => {
    if (emailRef.current) {
      emailRef.current.focus();
    }
  }, []);

  const handlePasswordKeyPress = (e: React.KeyboardEvent<HTMLInputElement>): void => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Please enter both email and password');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      const result = await UserLogin(email, password);
      if (result.status === 1) {

        const loginData = {
          token: result.data?.token || 'dummy-token', 
          user: {
            id: result.data?.user?.userID || -1,
            name: result.data?.user?.userName || "unknown",
            email: result.data?.user?.email || "unknown"
          },
          expiresIn: result.expiresIn || 24 * 60 * 60 // 24 hours in seconds
        };

        // Store auth data
        login(loginData);

        // Start SignalR connection after successful login
        await startConnection();

        // subscribe to push-notification
        //await enablePush(loginData.user.id, loginData.token);
        await ensurePushSubscribed(loginData.user.id, loginData.token);

        // Navigate to translist using React Router
        navigate('/translist');
      }

    } catch (err) {
      setError('Login failed. Please check your credentials.');
      console.error('Login error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8 login-container">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Sign in to your account
          </h2>
        </div>

        <div className="mt-8 space-y-6">
          <div className="rounded-md shadow-sm -space-y-px">
            <div className="login-input-row">
              <label htmlFor="email" className="sr-only">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="text"
                ref={emailRef}
                required
                className="relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                placeholder="Email"
                value={email}
                onChange={(e) => setUseremail(e.target.value)}
                disabled={isLoading}
              />
            </div>

            <div className="login-input-row">
              <label htmlFor="password" className="sr-only">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                className="relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                placeholder="Password"
                value={password}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
                onKeyPress={handlePasswordKeyPress}
                disabled={isLoading}
              />
            </div>
          </div>

          {error && (
            <div className="text-red-600 text-sm text-center login-error-message">
              {error}
            </div>
          )}

          <div className="login-button-row">
            <button
              type="button"
              onClick={handleLogin}
              disabled={isLoading}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Signing in...' : 'Sign in'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;