import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import GlobalAlerts from '../components/GlobalAlerts';
import TransactionList from '../pages/TransactionList';
import Login from '../pages/Login';
import ProtectedRoute from './ProtectedRoute';
import AppShell from '../layout/AppShell';

export default function AppRoutes() {
    return (
        <Router>
            <GlobalAlerts />
            <Routes>
                {/* Public */}
                <Route path="/" element={<Login />} />

                {/* Protected */}
                <Route element={<ProtectedRoute />}>
                    <Route element={<AppShell />}>
                    {/* <Route index element={<Dashboard />} /> */}
                    <Route path="translist" element={<TransactionList />} />
                    {/* add more: reports, settings, etc. */}
                    </Route>
                </Route>
            </Routes>
        </Router>
    )
}